﻿namespace TccFaatcarNew.Models
{
    public class SMotoristaModel
    {
        public string Email { get; set; }

        public string Senha { get; set; }

        public string Nome { get; set; }

        public string Marca { get; set; }

        public string Modelo { get; set; }

        public string Cor { get; set; }

        public string Placa { get; set; }

        public string CMotorista { get; set; }

        public string Ra { get; set; }



    }

}
