﻿namespace TccFaatcarNew.Models
{
    public class AsenhaModel
    {

        public string Email { get; set; }

    }
}
