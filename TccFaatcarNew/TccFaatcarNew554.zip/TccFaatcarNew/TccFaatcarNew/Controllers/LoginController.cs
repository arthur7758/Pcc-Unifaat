﻿using Microsoft.AspNetCore.Mvc;

namespace TccFaatcarNew.Controllers
{
    public class LoginController: Controller
    {

        public IActionResult SMotorista()
        {
            return View();
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult CadastrarSe()
        {
            return View();
        }

        public IActionResult Asenha()
        {
            return View();
        }

    }
}
